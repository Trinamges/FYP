<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\FinishesTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\FinishesTable Test Case
 */
class FinishesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\FinishesTable
     */
    public $Finishes;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.Finishes',
        'app.Items'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Finishes') ? [] : ['className' => FinishesTable::class];
        $this->Finishes = TableRegistry::getTableLocator()->get('Finishes', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Finishes);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}

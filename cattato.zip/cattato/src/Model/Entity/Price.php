<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Price Entity
 *
 * @property int $id
 * @property int $item_id
 * @property int|null $quantity_1
 * @property int|null $quantity_2
 * @property int|null $quantity_3
 * @property int|null $quantity_4
 * @property int|null $quantity_5
 * @property int|null $quantity_6
 * @property int|null $quantity_7
 * @property float|null $price_1
 * @property float|null $price_2
 * @property float|null $price_3
 * @property float|null $price_4
 * @property float|null $price_5
 * @property float|null $price_6
 * @property float|null $price_7
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 *
 * @property \App\Model\Entity\Item $item
 */
class Price extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'item_id' => true,
        'quantity_1' => true,
        'quantity_2' => true,
        'quantity_3' => true,
        'quantity_4' => true,
        'quantity_5' => true,
        'quantity_6' => true,
        'quantity_7' => true,
        'price_1' => true,
        'price_2' => true,
        'price_3' => true,
        'price_4' => true,
        'price_5' => true,
        'price_6' => true,
        'price_7' => true,
        'created' => true,
        'modified' => true,
        'item' => true
    ];
}

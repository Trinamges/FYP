<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Finishes Controller
 *
 * @property \App\Model\Table\FinishesTable $Finishes
 *
 * @method \App\Model\Entity\Finish[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class FinishesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $finishes = $this->paginate($this->Finishes);

        $this->set(compact('finishes', 'currentUser'));
    }

    /**
     * View method
     *
     * @param string|null $id Finish id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $finish = $this->Finishes->get($id);

        $this->set('finish', $finish);
        $this->set(compact('currentUser'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $finish = $this->Finishes->newEntity();
        if ($this->request->is('post')) {
            $finish = $this->Finishes->patchEntity($finish, $this->request->getData());
            if ($this->Finishes->save($finish)) {
                $this->Flash->success(__('The finish has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The finish could not be saved. Please, try again.'));
        }
        $this->set(compact('finish', 'currentUser'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Finish id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $finish = $this->Finishes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $finish = $this->Finishes->patchEntity($finish, $this->request->getData());
            if ($this->Finishes->save($finish)) {
                $this->Flash->success(__('The finish has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The finish could not be saved. Please, try again.'));
        }
        $this->set(compact('finish', 'currentUser'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Finish id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }
        
        $this->request->allowMethod(['post', 'delete']);
        $finish = $this->Finishes->get($id);
        if ($this->Finishes->delete($finish)) {
            $this->Flash->success(__('The finish has been deleted.'));
        } else {
            $this->Flash->error(__('The finish could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}

<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Utility\Text;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Event\Event;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{

    public function initialize() {
        parent::initialize();
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $users = $this->paginate($this->Users);

        $this->set(compact('users'));
        
    }

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        // Allow users to register and logout.
        // You should not add the "login" action to allow list. Doing so would
        // cause problems with normal functioning of AuthComponent.
        $this->Auth->allow(['register', 'logout']);
    }

    //Login method
    public function login()
    {
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user) {
                $this->Auth->setUser($user);
                return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
            }
            $this->Flash->error(__('Invalid username or password, try again'));
        }
    }

    //Logout method
    public function logout()
    {
        $this->Flash->success(__('You have successfully logged out.'));
        return $this->redirect($this->Auth->logout());
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $user = $this->Users->get($id, [
            'contain' => ['Address', 'BadgeOrders']
        ]);

        $this->set('user', $user);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function register()
    {
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user->user_id = Text::uuid();
            $user->user_type = 0;
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'login']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }
        
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}

<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Items Controller
 *
 * @property \App\Model\Table\ItemsTable $Items
 *
 * @method \App\Model\Entity\Item[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ItemsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $items = $this->paginate($this->Items);

        $this->set(compact('items', 'currentUser'));
    }

    /**
     * View method
     *
     * @param string|null $id Item id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $item = $this->Items->get($id, [
            'contain' => ['BadgeOrders', 'Prices']
        ]);

        $this->set('item', $item);
        $this->set(compact('currentUser'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $item = $this->Items->newEntity();
        if ($this->request->is('post')) {
            $item = $this->Items->patchEntity($item, $this->request->getData());
            if ($this->Items->save($item)) {
                $this->Flash->success(__('The item has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The item could not be saved. Please, try again.'));
        }
        $this->set(compact('item', 'currentUser'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Item id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $item = $this->Items->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $item = $this->Items->patchEntity($item, $this->request->getData());
            if ($this->Items->save($item)) {
                $this->Flash->success(__('The item has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The item could not be saved. Please, try again.'));
        }
        $this->set(compact('item', 'currentUser'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Item id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }
        
        $this->request->allowMethod(['post', 'delete']);
        $item = $this->Items->get($id);
        if ($this->Items->delete($item)) {
            $this->Flash->success(__('The item has been deleted.'));
        } else {
            $this->Flash->error(__('The item could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}

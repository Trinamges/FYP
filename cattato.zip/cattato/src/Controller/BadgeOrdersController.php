<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\Table;
use Cake\Utility\Text;
use Cake\I18n\Time;
/**
 * BadgeOrders Controller
 *
 * @property \App\Model\Table\BadgeOrdersTable $BadgeOrders
 *
 * @method \App\Model\Entity\BadgeOrder[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class BadgeOrdersController extends AppController
{

    public function initialize() {
        parent::initialize();
        $this->loadModel('Addresses');
        $this->loadModel('Finishes');
        $this->loadModel('Carts');
        $this->loadModel('Prices');
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $currentUser = $this->Auth->user('user_type');
        $user_id = $this->Auth->user('id');
        if($currentUser == 2)
        {
            $this->paginate = [
                'contain' => ['Carts', 'Users', 'Addresses', 'Items', 'Finishes']
            ];
            $badgeOrders = $this->paginate($this->BadgeOrders);

        }
        else
        {
            $this->paginate = [
            'contain' => ['Carts', 'Users', 'Addresses', 'Items', 'Finishes']
            ];
            $orders =  $this->BadgeOrders->find('all')->where(['BadgeOrders.user_id' => $user_id]);
            $badgeOrders = $this->paginate($orders);
        }

        $this->set(compact('badgeOrders', 'currentUser'));
    }

    public function manageorders()
    {
        $currentUser = $this->Auth->user('user_type');
        $user_id = $this->Auth->user('id');
        if($currentUser == 2)
        {
            $this->paginate = [
                'contain' => ['Carts', 'Users', 'Addresses', 'Items', 'Finishes']
            ];
            $badgeOrders = $this->paginate($this->BadgeOrders->find()->where(['status !=' => 4]));

        }
        else
        {
            if($this->Auth->user('user_type') != 2)	{
                $this->Flash->error(__('You are not authorized to access that location.'));
                return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
            }
        }

        $this->set(compact('badgeOrders', 'currentUser'));
    }


    public function monthlyreport()
    {
        $now = Time::now();
        $currentUser = $this->Auth->user('user_type');
        $user_id = $this->Auth->user('id');
        if($currentUser == 2)
        {
            $this->paginate = [
                'contain' => ['Carts', 'Users', 'Addresses', 'Items', 'Finishes']
            ];
            $badgeOrders = $this->paginate($this->BadgeOrders->find()->where(['MONTH(BadgeOrders.created) = MONTH(NOW())']));

        }
        else
        {
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['action' => 'index']);
        }

        $this->set(compact('badgeOrders', 'currentUser'));
    }

    /**
     * View method
     *
     * @param string|null $id Badge Order id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $currentUser = $this->Auth->user('user_type');
        $badgeOrder = $this->BadgeOrders->get($id, [
            'contain' => ['Carts', 'Users', 'Addresses', 'Items']
        ]);

        $this->set('badgeOrder', $badgeOrder);
        $this->set(compact('currentUser'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        //Gets current user type and user id
        $currentUser = $this->Auth->user('user_type');
        $user_id = $this->Auth->user('id');
        //Warning pop-up
        $this->Flash->success(__('You may not change the image after you have submitted it.'));
        //Creates a new entity
        $badgeOrder = $this->BadgeOrders->newEntity();

        //When user posts form
        if ($this->request->is('post')) {
            //Get Data from the ctp file
            $total = $this->request->data('total');
            $item_id = $this->request->getData('item_id');
            $finish_id = $this->request->getData('finish_id');
            $quantity = $this->request->getData('quantity');
            $file = $this->request->data('image');
            //Checks if heart badge and mylar, the business does not do mylar heart badges.
            if($item_id == 4 && $finish_id == 1)
            {
                $this->Flash->error(__('We do not do Mylar for Heart Badges, sorry for the inconvenience.'));
            }
            else
            {                
                //Check if cart exists
                $carts = $this->Carts->find()->where(['user_id' => $user_id, 'is_active' => 1])->extract('id')->first();
                $image = Text::uuid(); 
                if($carts == null)
                {
                    //Cart Details if cart does not exist, make a new cart
                    $cart_id = Text::uuid();
                    $createCart = $this->Carts->newEntity();
                    $createCart->id = $cart_id;
                    $createCart->user_id = $user_id;
                    $createCart->is_active = 1;
                    
                    //Badge Order Details
					$badgeOrder->image = $image;
                    $badgeOrder->status = 5;
                    $badgeOrder->user_id = $user_id;
                    $badgeOrder->cart_id = $cart_id;
                    $badgeOrder->item_id = $item_id;
                    $badgeOrder->finish_id = $finish_id;
                    $badgeOrder->address_id = $this->request->getData('address_id');
                    $badgeOrder = $this->BadgeOrders->patchEntity($badgeOrder, $this->request->getData());
                    
                    //Moves file
					if(!move_uploaded_file($file['tmp_name'], 'img/'.$image)) {
						$this->Flash->error(__('There is something wrong with your image file. Please, try again.'));
                    }
                    else
                    {
                        //Saves
                        if ($this->BadgeOrders->save($badgeOrder) && $this->Carts->save($createCart)) {
                            $this->Flash->success(__('The badge order has been added to cart, you may still edit it until production starts.'));
                        return $this->redirect(['action' => 'index']);
                        }
                    }
                }
                    else
                    {
                        //If Cart already exists, add it to that cart
                        $badgeOrder->image = $image;
                        $badgeOrder->status = 5;
                        $badgeOrder->user_id = $user_id;
                        $badgeOrder->cart_id = $carts;
                        $badgeOrder->total = $total;
                        $badgeOrder->item_id = $item_id;
                        $badgeOrder->finish_id = $finish_id;
                        $badgeOrder->address_id = $this->request->getData('address_id');
                        $badgeOrder = $this->BadgeOrders->patchEntity($badgeOrder, $this->request->getData());
                        //Moves file
                        if(!move_uploaded_file($file['tmp_name'], 'img/'.$image)) {
                            $this->Flash->error(__('There is something wrong with your image file. Please, try again.'));
                        }
                        else
                        {
                            if ($this->BadgeOrders->save($badgeOrder)) {
                                $this->Flash->success(__('The badge order has been added to cart, you may still edit it until production starts.'));
                            return $this->redirect(['action' => 'index']);
                            }
                        }

                    }
            }
            $this->Flash->error(__('The badge order could not be saved. Please, try again.'));
        }
        //Get Addresses
        $getAddresses= $this->Addresses->find('all')->where(['user_id' => $user_id]);
        $finishes = $this->BadgeOrders->Finishes->find('list', ['limit' => 200]);
        $items = $this->BadgeOrders->Items->find('list', ['limit' => 200]);
        $this->set(compact('badgeOrder', 'carts', 'users', 'getAddresses', 'items', 'finishes', 'prices', 'currentUser'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Badge Order id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $currentUser = $this->Auth->user('user_type');
        $file = $this->request->data('image');
        $image = $this->BadgeOrders->find()->where(['id' => $id])->extract('image')->First();
        $status = $this->BadgeOrders->find()->where(['id' => $id])->extract('status')->First();
        $user_id = $this->BadgeOrders->find()->where(['id' => $id])->extract('user_id')->First();
        $getTotal = $this->BadgeOrders->find()->where(['id' => $id])->extract('total')->First();
        $badgeOrder = $this->BadgeOrders->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            
            $total = $this->request->data('total');
            $badgeOrder->item_id = $this->request->getData('item_id');
            $badgeOrder->finish_id = $this->request->getData('finish_id');
            $badgeOrder->address_id = $this->request->getData('address_id');
            $badgeOrder->quantity = $this->request->getData('quantity');
            $badgeOrder->notes = $this->request->getData('notes');
            $badgeOrder->total = $total;
            if($this->request->getData('item_id') == 4 && $this->request->getData('finish_id') == 1)
            {
                $this->Flash->error(__('We do not do Mylar for Heart Badges, sorry for the inconvenience.'));
            }
            else
            {
                if ($this->BadgeOrders->save($badgeOrder)) {
                    $this->Flash->success(__('The badge order has been submitted, you may still edit it until production starts.'));
                    return $this->redirect(['action' => 'index']);
                }

            }
            $this->Flash->error(__('The badge order could not be saved. Please, try again.'));
        }
        $getAddresses = $this->Addresses->find('all')->where(['user_id' => $user_id]);
        $finishes = $this->BadgeOrders->Finishes->find('list', ['limit' => 200]);
        $items = $this->BadgeOrders->Items->find('list', ['limit' => 200]);
        $this->set(compact('badgeOrder', 'items', 'getAddresses', 'finishes', 'getTotal', 'currentUser'));
    }

    public function update($id = null)
    {
        
        //Validation function
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }

        $badgeOrder = $this->BadgeOrders->get($id, [
            'contain' => []
        ]);
        
        $badgeOrder->status = $this->request->getData('status');
        if ($this->request->is(['patch', 'post', 'put'])) {
            if ($this->BadgeOrders->save($badgeOrder)) {
                $this->Flash->success(__('The order has been updated.'));

                return $this->redirect(['action' => 'manageorders']);
            }
            $this->Flash->error(__('The order could not be saved. Please, try again.'));
        }
        $users = $this->Carts->Users->find('list', ['limit' => 200]);
        $this->set(compact('badgeOrder', 'users', 'currentUser'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Badge Order id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $badgeOrder = $this->BadgeOrders->get($id);
        if ($this->BadgeOrders->delete($badgeOrder)) {
            $this->Flash->success(__('The badge order has been deleted.'));
        } else {
            $this->Flash->error(__('The badge order could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}

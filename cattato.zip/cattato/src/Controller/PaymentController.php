<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Utility\Text;

/**
 * Payment Controller
 *
 * @property \App\Model\Table\PaymentTable $Payment
 *
 * @method \App\Model\Entity\Payment[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PaymentController extends AppController
{
    
    public function initialize() {
        parent::initialize();
        $this->loadModel('Addresses');
        $this->loadModel('BadgeOrders');
        $this->loadModel('Finishes');
        $this->loadModel('Carts');
        $this->loadModel('Prices');
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }
        $this->paginate = [
            'contain' => ['Carts']
        ];
        $p = $this->Payment->find('all')->where(['Payment.is_active' => 1]);
        $payment = $this->paginate($p);

        $this->set(compact('payment', 'currentUser'));
    }

    /**
     * View method
     *
     * @param string|null $id Payment id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }
        $payment = $this->Payment->get($id, [
            'contain' => ['Carts']
        ]);

        $this->set('payment', $payment);
        $this->set(compact('currentUser'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function payment()
    {
        $user_id = $this->Auth->user('id');
        $currentUser = $this->Auth->user('user_type.');
        $payment = $this->Payment->newEntity();
        $this->paginate = [
            'contain' => ['Carts', 'Users', 'Addresses', 'Items', 'Finishes']
        ];
        //Get cart and items from the cart
        $getCart = $this->Carts->find()->where(['is_active' => 1, 'user_id' => $user_id])->First();

        //Checks if there are any carts that arent paid for
        if($getCart == null)
        {
            $this->Flash->error(__('Your cart is empty.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);

        }

        //Get the items from the cart
        $getItems = $this->BadgeOrders->find()->where(['cart_id' => $getCart->id]);
        $items = $this->paginate($getItems);

        //Receipt data collecting thing
        $file = $this->request->data('receipt');
        $receipt = Text::uuid();

        if ($this->request->is('post')) {
            
            //Gettin' input data, updating cart to be inactive and make payment active
            $payment->cart_id = $getCart->id;
            $getCart->is_active = 0;
            $payment->is_active = 1;
            $payment->total = $this->request->getData('total');
            $payment->receipt = $receipt;
            foreach($getItems as $g)
            {
                $g->status = 0;
                $this->BadgeOrders->save($g);
            }
            //Uploading receipt
            if(!move_uploaded_file($file['tmp_name'], 'img/'.$receipt)) {
                $this->Flash->error(__('There is something wrong with your file. Please, try again.'));
            }
            else
            {
                //Success
                if ($this->Payment->save($payment) && $this->Carts->save($getCart)) {
                    $this->Flash->success(__('Please wait until payment is approved.'));
                    return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
                }
            }

            $payment = $this->Payment->patchEntity($payment, $this->request->getData());
            
            $this->Flash->error(__('The payment could not be saved. Please, try again.'));
        }
        $carts = $this->Payment->Carts->find('list', ['limit' => 200]);
        $this->set(compact('payment', 'carts', 'items', 'currentUser'));
    }


    public function approve($id = null)
    {
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }
        $payment = $this->Payment->get($id);
        $getCart = $this->Payment->find()->where(['id' => $id])->First();
        $getItems = $this->BadgeOrders->find()->where(['cart_id' => $getCart->cart_id]);
        foreach($getItems as $g)
        {
            $g->status = 1;
            $this->BadgeOrders->save($g);
        }
        $payment->is_active = 0;
        if ($this->Payment->save($payment)) {
            
            $getItems->set(['status' => 5])->where(['cart_id' => $getCart->id])->execute();
            $this->Flash->success(__('The payment has been approved.'));
        } else {
            $this->Flash->error(__('The payment could not be approved. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function deny($id = null)
    {
        $currentUser = $this->Auth->user('user_type');
        if($this->Auth->user('user_type') != 2)	{
            $this->Flash->error(__('You are not authorized to access that location.'));
            return $this->redirect(['controller' => 'BadgeOrders', 'action' => 'index']);
        }
        $payment = $this->Payment->get($id);
        $getCart = $this->Payment->find()->where(['id' => $id])->First();
        $getItems = $this->BadgeOrders->find()->where(['cart_id' => $getCart->cart_id]);
        foreach($getItems as $g)
        {
            $g->status = 6;
            $this->BadgeOrders->save($g);
        }
        $payment->is_active = 0;
        if ($this->Payment->save($payment)) {
            
            $getItems->set(['status' => 5])->where(['cart_id' => $getCart->id])->execute();
            $this->Flash->success(__('The payment has been denied.'));
        } else {
            $this->Flash->error(__('The payment could not be denied. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
